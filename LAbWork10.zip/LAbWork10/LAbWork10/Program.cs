﻿using System;
using System.Management;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Паспорт компьютера\n");
        GetProcessorInfo();    // Получение информации о процессоре
        GetMemoryInfo();       // об оперативной памяти
        GetMotherboardInfo();  // о материнской плате
        GetBiosInfo();         // о BIOS
    }

    static void GetProcessorInfo()
    {
        // WQL-запрос для получения информации о процессорах
        ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT * FROM Win32_Processor");

        // Перебираем найденные объекты (экземпляры класса Win32_Processor)
        foreach (ManagementObject obj in searcher.Get())
        {
            Console.WriteLine("Процессор: " + obj["Name"]);
            Console.WriteLine("Количество ядер: " + obj["NumberOfCores"]);
        }
        Console.WriteLine();
    }

    static void GetMemoryInfo()
    {
        // WQL-запрос для получения информации об оперативной памяти
        ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT * FROM Win32_PhysicalMemory");

        // Перебираем найденные объекты (экземпляры класса Win32_PhysicalMemory)
        foreach (ManagementObject obj in searcher.Get())
        {
            Console.WriteLine("Объем оперативной памяти: " + (Convert.ToUInt64(obj["Capacity"]) / (1024 * 1024)) + " МБ"); // Преобразование в МБ
        }
        Console.WriteLine();
    }

    static void GetMotherboardInfo()
    {
        // WQL-запрос для получения информации о материнской плате
        ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT * FROM Win32_BaseBoard");

        // Перебираем найденные объекты (экземпляры класса Win32_BaseBoard)
        foreach (ManagementObject obj in searcher.Get())
        {
            Console.WriteLine("Модель материнской платы: " + obj["Product"]);
            Console.WriteLine("Серийный номер материнской платы: " + obj["SerialNumber"]);
        }
        Console.WriteLine();
    }

    static void GetBiosInfo()
    {
        // WQL-запрос для получения информации о BIOS
        ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT * FROM Win32_BIOS");

        // Перебираем найденные объекты (экземпляры класса Win32_BIOS)
        foreach (ManagementObject obj in searcher.Get())
        {
            Console.WriteLine("Версия BIOS: " + obj["Version"]);
        }
        Console.WriteLine();
    }
}
