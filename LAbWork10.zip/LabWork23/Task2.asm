%include "io.inc"
section .data
    fmt_s db "%s",10,0 ;вывод строки
    fmt_d db "%d",0 ;ввод целого числа
    prompt_i db "i: ",0 ;ввод i
    prompt_n db "n: ",0 ;ввод n

    s1 db "Example string",0 ; исходная строка
    s2 db 64 dup(0) ; приемник

    i_val dd 0 ; место для сохранения i
    n_val dd 0 ; место для сохранения n

section .text
    global main
main:
    push ebp
    mov ebp, esp

    ; ввод i
    push dword prompt_i
    push dword fmt_s
    call printf
    add esp,8
    push dword i_val
    push dword fmt_d
    call scanf
    add esp,8

    ; ввод n
    push dword prompt_n
    push dword fmt_s
    call printf
    add esp,8
    push dword n_val
    push dword fmt_d
    call scanf
    add esp,8

    mov ecx, [i_val]      ; ECX = i (начальная позиция, 0-based)
    mov edx, [n_val]      ; EDX = n (длина)

    lea esi, [s1 + ecx]   ; ESI -> s1 + i
    mov edi, s2           ; EDI -> s2

copy_loop:
    cmp edx, 0
    je done
    mov al, [esi]
    mov [edi], al
    inc esi
    inc edi
    dec edx
    jmp copy_loop

done:
    mov byte [edi], 0     
    push dword s2
    push dword fmt_s
    call printf
    add esp,8

    mov esp, ebp
    pop ebp
    ret
