﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LabWork1
{
    /// <summary>
    /// Логика взаимодействия для StartProcessWindow.xaml
    /// </summary>
    public partial class StartProcessWindow : Window
    {
        public StartProcessWindow()
        {
            InitializeComponent();
        }

        private void BrowseButton_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new OpenFileDialog
            {
                Filter = "Executable files (*.exe)|*.exe",
                Title = "Выберите исполняемый файл"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                ExecutablePathTextBox.Text = openFileDialog.FileName;
            }
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            string executablePath = ExecutablePathTextBox.Text;

            if (string.IsNullOrEmpty(executablePath))
            {
                MessageBox.Show("Пожалуйста, укажите путь к исполняемому файлу.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                Process.Start(executablePath);
                this.DialogResult = true; // Устанавливаем результат диалога в true
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при запуске приложения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
