﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LabWork22.Models;
using System.IO;
using System.Security.Cryptography;

namespace LabWork22
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private static readonly byte[] key = new byte[]
        {
            0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
            0x09, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16
        };

        private Random random = new Random(); // Генератор случайных чисел
        public MainWindow()
        {
            InitializeComponent();
            LoadPasswords(); // Загружаем пароли при инициализации окна
        }

        private void LoadPasswords()
        {
            string filePath = @"C:\Users\Victoriya\Desktop\Education\4 СЕМЕСТР\Системное программирование\LabWork22\LabWork22\Assest\passwords.txt";

            if (File.Exists(filePath))
            {
                List<PasswordEntry> entries = new List<PasswordEntry>();

                foreach (var line in File.ReadAllLines(filePath))
                {
                    var parts = line.Split(';');
                    if (parts.Length == 3)
                    {
                        entries.Add(new PasswordEntry
                        {
                            Site = parts[0].Trim(),
                            Login = parts[1].Trim(),
                            Password = Decrypt(parts[2].Trim())
                        });
                    }
                }

                passwordsListView.ItemsSource = entries;
            }
            else
            {
                MessageBox.Show("Файл passwords.txt не найден.");
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            string site = siteTextBox.Text;
            string login = loginTextBox.Text;
            string password = passwordTextBox.Text;

            if (string.IsNullOrWhiteSpace(site) || string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Пожалуйста, заполните все поля.");
                return;
            }

            string encryptedPassword = Encrypt(password);
            string newEntry = $"{site};{login};{encryptedPassword}{Environment.NewLine}";

            string filePath = @"C:\Users\Victoriya\Desktop\Education\4 СЕМЕСТР\Системное программирование\LabWork22\LabWork22\Assest\passwords.txt";

            try
            {
                File.AppendAllText(filePath, newEntry);
                LoadPasswords();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка при добавлении данных в файл: {ex.Message}");
            }

            siteTextBox.Clear();
            loginTextBox.Clear();
            passwordTextBox.Clear();
        }

        private string Encrypt(string plainText)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = key;
                aes.GenerateIV();
                byte[] iv = aes.IV;

                using (MemoryStream ms = new MemoryStream())
                {
                    // Сохранение IV в поток
                    ms.Write(iv, 0, iv.Length);

                    using (CryptoStream cs = new CryptoStream(ms, aes.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        using (StreamWriter sw = new StreamWriter(cs))
                        {
                            sw.Write(plainText);
                        }
                    }

                    return Convert.ToBase64String(ms.ToArray()); // Возвращаем зашифрованный текст
                }
            }
        }

        private string Decrypt(string cipherText)
        {
            try
            {
                byte[] fullCipher = Convert.FromBase64String(cipherText);
                byte[] iv = new byte[16];
                Array.Copy(fullCipher, 0, iv, 0, iv.Length);

                byte[] cipher = new byte[fullCipher.Length - iv.Length];
                Array.Copy(fullCipher, iv.Length, cipher, 0, cipher.Length);

                using (Aes aes = Aes.Create())
                {
                    aes.Key = key;
                    aes.IV = iv;

                    using (MemoryStream ms = new MemoryStream(cipher))
                    {
                        using (CryptoStream cs = new CryptoStream(ms, aes.CreateDecryptor(), CryptoStreamMode.Read))
                        {
                            using (StreamReader reader = new StreamReader(cs))
                            {
                                return reader.ReadToEnd();
                            }
                        }
                    }
                }
            }
            catch (FormatException fe)
            {
                MessageBox.Show($"Ошибка при декодировании Base64: {fe.Message}");
                return string.Empty;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при расшифровке: {ex.Message}");
                return string.Empty;
            }
        }


        private void GeneratePassword_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(passwordLengthTextBox.Text, out int length) && length > 0)
            {
                string password = GenerateRandomPassword(length);
                passwordTextBox.Text = password;
            }
            else
            {
                MessageBox.Show("Введите допустимую длину пароля (целое число).");
            }
        }

        private string GenerateRandomPassword(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            char[] passwordChars = new char[length];

            for (int i = 0; i < length; i++)
            {
                passwordChars[i] = chars[random.Next(chars.Length)];
            }

            return new string(passwordChars);
        }
    }
}