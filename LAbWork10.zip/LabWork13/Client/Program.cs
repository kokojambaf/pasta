﻿using System;
using System.Net.Sockets;
using System.Text;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            TcpClient client = new TcpClient("localhost", 5000);
            Console.WriteLine("Подключение к серверу...");

            NetworkStream stream = client.GetStream();
            byte[] buffer = new byte[256];

            // Читаем сообщение от сервера с запросом на ввод логина
            int bytesRead = stream.Read(buffer, 0, buffer.Length);
            Console.WriteLine(Encoding.UTF8.GetString(buffer, 0, bytesRead).Trim());

            // Ввод логина пользователем и отправка на сервер
            string login = Console.ReadLine();
            byte[] loginData = Encoding.UTF8.GetBytes(login);
            stream.Write(loginData, 0, loginData.Length);

            // Читаем сообщение от сервера с запросом на ввод пароля
            bytesRead = stream.Read(buffer, 0, buffer.Length);
            Console.WriteLine(Encoding.UTF8.GetString(buffer, 0, bytesRead).Trim());

            // Ввод пароля пользователем и отправка на сервер
            string password = Console.ReadLine();
            byte[] passwordData = Encoding.UTF8.GetBytes(password);
            stream.Write(passwordData, 0, passwordData.Length);

            // Чтение ответа сервера на аутентификацию
            bytesRead = stream.Read(buffer, 0, buffer.Length);
            string authResponse = Encoding.UTF8.GetString(buffer, 0, bytesRead).Trim();
            Console.WriteLine(authResponse); // Выводим ответ сервера

            // Если аутентификация прошла успешно
            if (authResponse != "Неверный логин или пароль.")
            {
                Console.WriteLine("Ожидание возможности ввода сообщения...");

                while (true)
                {
                    Console.Write("Введите сообщение для отправки на сервер (или 'exit' для выхода): ");
                    string message = Console.ReadLine();
                    if (message.ToLower() == "exit")
                    {
                        break; // Выход из программы
                    }

                    byte[] messageData = Encoding.UTF8.GetBytes(message);
                    stream.Write(messageData, 0, messageData.Length);
                    Console.WriteLine("Сообщение отправлено.");

                    // Ожидание ответа от сервера о получении сообщения
                    bytesRead = stream.Read(buffer, 0, buffer.Length);
                    string response = Encoding.UTF8.GetString(buffer, 0, bytesRead).Trim();
                    Console.WriteLine($"Ответ от сервера: {response}");
                }
            }

            client.Close(); // Закрываем соединение
        }
    }
}
