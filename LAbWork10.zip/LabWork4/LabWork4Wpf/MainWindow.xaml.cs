﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System;
using System.Collections.Generic;

namespace LabWork4Wpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LoadDrives();
            textBoxCurrentFolder.Text = Environment.CurrentDirectory; // Отображение пути к текущей папке
        }

        private void LoadDrives()
        {
            List<DriveInfoModel> drives = new List<DriveInfoModel>();

            foreach (DriveInfo drive in DriveInfo.GetDrives())
            {
                if (drive.IsReady)
                {
                    var driveModel = new DriveInfoModel
                    {
                        Name = drive.Name,
                        Type = drive.DriveType.ToString(),
                        TotalSize = FormatSize(drive.TotalSize),
                        UsedPercentage = $"{(drive.TotalSize - drive.AvailableFreeSpace) * 100 / drive.TotalSize} %",
                        FreeSpace = FormatSize(drive.AvailableFreeSpace)
                    };
                    drives.Add(driveModel);
                }
            }

            dataGridDrives.ItemsSource = drives;
        }


        private string FormatSize(long bytes)
        {
            const long KB = 1024;
            const long MB = KB * 1024;
            const long GB = MB * 1024;
            if (bytes >= GB)
                return $"{bytes / GB} ГБ";
            if (bytes >= MB)
                return $"{bytes / MB} МБ";
            if (bytes >= KB)
                return $"{bytes / KB} КБ";
            return $"{bytes} Б";
        }

        private void textBoxFolderInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                string folderPath = textBoxFolderInput.Text;

                if (Directory.Exists(folderPath))
                {
                    DisplayFolderInfo(folderPath);
                }
                else
                {
                    MessageBox.Show("Указанная папка не существует.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void DisplayFolderInfo(string folderPath)
        {
            try
            {
                var directoryInfo = new DirectoryInfo(folderPath);

                // Общее количество файлов и папок
                int fileCount = directoryInfo.GetFiles("*", SearchOption.AllDirectories).Length;
                int folderCount = directoryInfo.GetDirectories("*", SearchOption.AllDirectories).Length;

                // Общий размер папки
                long folderSize = directoryInfo.GetFiles("*", SearchOption.AllDirectories).Sum(f => f.Length);

                // Процент занятого места
                DriveInfo driveInfo = new DriveInfo(directoryInfo.Root.Name);
                double usedPercentage = (double)folderSize / driveInfo.TotalSize * 100;

                // Отображение информации
                textBlockFileCount.Text = $"Количество файлов: {fileCount}";
                textBlockFolderCount.Text = $"Количество папок: {folderCount}";
                textBlockFolderSize.Text = $"Размер папки: {FormatSize(folderSize)}";
                textBlockUsedPercentage.Text = $"% занятого места: {usedPercentage:F2} %";

                // Получение 10 самых больших файлов
                List<FileInfoModel> topFiles = directoryInfo.GetFiles("*", SearchOption.AllDirectories)
                    .OrderByDescending(f => f.Length)
                    .Take(10)
                    .Select(f => new FileInfoModel
                    {
                        FileName = f.Name,
                        FileSize = FormatSize(f.Length),
                        FilePath = f.FullName,
                        LastModified = f.LastWriteTime.ToString("dd.MM.yyyy HH:mm:ss")
                    }).ToList();

                listViewTopFiles.ItemsSource = topFiles;
            }
            catch (UnauthorizedAccessException ex)
            {
                MessageBox.Show($"Отказ в доступе: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }

    public class DriveInfoModel
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public string TotalSize { get; set; }
        public string UsedPercentage { get; set; }
        public string FreeSpace { get; set; }
    }
}
