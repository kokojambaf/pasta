﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Diagnostics;
//using Terminal.Gui;

//namespace GUI
//{
//    public class Program
//    {
//        private static TableView tableView;
//        private static List<ProcessInfo> processList;

//        static void Main(string[] args)
//        {
//            Application.Init();
//            var top = Application.Top;

//            var window = new Window("Process Manager")
//            {
//                Width = Dim.Fill(),
//                Height = Dim.Fill()
//            };

//            // Инициализация списка процессов
//            processList = new List<ProcessInfo>();
//            tableView = new TableView()
//            {
//                Width = Dim.Fill(),
//                Height = Dim.Fill(15)
//            };

//            // Создание данных для отображения в TableView
//            var columns = new TableView.Column[]
//            {
//                new TableView.Column("Id", 6),
//                new TableView.Column("Process Name", 25),
//                new TableView.Column("Memory Usage (KB)", 18)
//            };

//            tableView.AddColumns(columns);

//            // Создание текстового поля для ввода имени процесса
//            var processNameField = new TextField("Введите имя процесса...")
//            {
//                Width = Dim.Fill(),
//            };

//            // Кнопка запуска процесса
//            var launchButton = new Button("Запустить");
//            launchButton.Clicked += () =>
//            {
//                try
//                {
//                    string processName = processNameField.Text.ToString();
//                    if (string.IsNullOrWhiteSpace(processName))
//                    {
//                        MessageBox.ErrorQuery(50, 7, "Ошибка", "Введите имя процесса.", "OK");
//                        return;
//                    }

//                    var startInfo = new ProcessStartInfo
//                    {
//                        FileName = processName,
//                        UseShellExecute = true,
//                    };

//                    Process.Start(startInfo);
//                    UpdateProcessList();
//                }
//                catch (Exception ex)
//                {
//                    MessageBox.ErrorQuery(50, 7, "Ошибка", ex.Message, "OK");
//                }
//            };

//            // Кнопка завершения процесса
//            var killButton = new Button("Завершить");
//            killButton.Clicked += () =>
//            {
//                if (tableView.SelectedRow >= 0)
//                {
//                    var selectedProcessId = processList[tableView.SelectedRow].Id;
//                    try
//                    {
//                        var process = Process.GetProcessById(selectedProcessId);
//                        process.Kill();
//                        UpdateProcessList();
//                    }
//                    catch (Exception ex)
//                    {
//                        MessageBox.ErrorQuery(50, 7, "Ошибка", ex.Message, "OK");
//                    }
//                }
//            };

//            // Добавление элементов управления в окно
//            window.Add(processNameField, launchButton, killButton, tableView);
//            top.Add(window);

//            UpdateProcessList();

//            Application.Run();
//        }

//        // Метод для обновления списка процессов
//        private static void UpdateProcessList()
//        {
//            var processes = Process.GetProcesses();
//            processList.Clear();

//            foreach (var process in processes)
//            {
//                var memoryUsage = (process.WorkingSet64 / 1024).ToString();
//                processList.Add(new ProcessInfo
//                {
//                    Id = process.Id,
//                    ProcessName = process.ProcessName,
//                    MemoryUsage = memoryUsage
//                });
//            }

//            // Установка данных в TableView
//            tableView.SetSource(processList);
//        }
//    }

//    // Класс для хранения информации о процессе
//    public class ProcessInfo
//    {
//        public int Id { get; set; }
//        public string ProcessName { get; set; }
//        public string MemoryUsage { get; set; }

//        public override string ToString() =>
//            $"{Id} {ProcessName} {MemoryUsage} KB";
//    }
//}