﻿using System;
using System.Threading;

class Program
{
    static void Main(string[] args)
    {
        // Создаем 4 потока с разными приоритетами
        Thread thread1 = new Thread(() => WriteString(1)) { Priority = ThreadPriority.Lowest };
        Thread thread2 = new Thread(() => WriteString(2)) { Priority = ThreadPriority.Normal };
        Thread thread3 = new Thread(() => WriteString(3)) { Priority = ThreadPriority.AboveNormal };
        Thread thread4 = new Thread(() => WriteString(4)) { Priority = ThreadPriority.Highest };

        // Запускаем потоки
        thread1.Start();
        thread2.Start();
        thread3.Start();
        thread4.Start();

        // Ждем завершения всех потоков
        thread1.Join();
        thread2.Join();
        thread3.Join();
        thread4.Join();

        Console.WriteLine("Все потоки завершены.");
    }

    static void WriteString(int threadNumber)
    {
        Console.WriteLine($"Поток {threadNumber} запущен.");

        // Имитация работы потока
        Thread.Sleep(1000); 

        Console.WriteLine($"Поток {threadNumber} завершен.");
    }
}

