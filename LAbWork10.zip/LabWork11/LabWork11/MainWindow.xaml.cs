﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace LabWork11
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Label timeLabel;
        private Image displayImage;
        private string[] imageFiles;
        private int currentImageIndex = 0;
        private Random random = new Random();
        private DispatcherTimer timer;
        private int state; // 0 - пустой экран, 1 - часы, 2 - перемещение часов, 3 - фотографии
        private double velocityX = 5; // Скорость по X
        private double velocityY = 5; // Скорость по Y
        private double directionX = 1; // Направление по X
        private double directionY = 1; // Направление по Y

        public MainWindow()
        {
            InitializeComponent();

            // Убираем границы окна
            WindowStyle = WindowStyle.None;
            // Устанавливаем черный фон
            Background = Brushes.Black;
            // Разворачиваем окно на весь экран
            WindowState = WindowState.Maximized;

            // Создаем метку для отображения времени
            timeLabel = new Label
            {
                FontSize = 40,
                Foreground = Brushes.White,
                HorizontalAlignment = HorizontalAlignment.Left,
                VerticalAlignment = VerticalAlignment.Top
            };

            // Создаем изображение для отображения
            displayImage = new Image
            {
                Stretch = Stretch.Uniform,
            };

            // Инициализируем таймер
            timer = new DispatcherTimer();
            timer.Tick += Timer_Tick;

            // Установка состояния заставки на часы
            SetState(1);
        }

        private void SetState(int newState)
        {
            state = newState;
            Content = null; // Сбрасываем содержимое окна

            if (state == 1) // Часы
            {
                Content = timeLabel; // Добавляем метку на окно
                CenterLabel(); // Центрируем метку
            }
            else if (state == 2) // Перемещение часов
            {
                Content = timeLabel; // Добавляем метку на окно
                CenterLabel(); // Начинаем движение из центра
                directionX = random.Next(0, 2) == 0 ? 1 : -1; // Случайное направление по X
                directionY = random.Next(0, 2) == 0 ? 1 : -1; // Случайное направление по Y
            }
            else if (state == 3) // Фотографии
            {
                Content = displayImage; // Добавляем изображение на окно
                ChangeImage();
            }

            timer.Interval = TimeSpan.FromSeconds(state == 3 ? 10 : 1);
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            switch (state)
            {
                case 1: // Простые часы
                    UpdateTime();
                    CenterLabel();
                    break;
                case 2: // Перемещение часов
                    UpdateTime();
                    MoveLabel(); // Перемещение метки
                    break;
                case 3: // Изменение изображений
                    ChangeImage();
                    break;
            }
        }

        private void UpdateTime()
        {
            timeLabel.Content = DateTime.Now.ToString("HH:mm:ss");
        }

        private void MoveLabel()
        {
            // Текущие координаты
            double offsetX = (double)timeLabel.Margin.Left;
            double offsetY = (double)timeLabel.Margin.Top;

            // Обновляем координаты с учетом направления и скорости
            offsetX += velocityX * directionX;
            offsetY += velocityY * directionY;

            // Проверяем границы окна
            if (offsetX <= 0 || offsetX >= Width - timeLabel.ActualWidth)
            {
                directionX *= -1; // Меняем направление по X
            }

            if (offsetY <= 0 || offsetY >= Height - timeLabel.ActualHeight)
            {
                directionY *= -1; // Меняем направление по Y
            }

            // Устанавливаем новые значения отступов (margin)
            timeLabel.Margin = new Thickness(offsetX, offsetY, 0, 0);
        }

        private void CenterLabel()
        {
            // Устанавливаем метку в центр окна
            double centerX = (Width / 2) - (timeLabel.ActualWidth / 2);
            double centerY = (Height / 2) - (timeLabel.ActualHeight / 2);
            timeLabel.Margin = new Thickness(centerX, centerY, 0, 0);
        }

        private void ChangeImage()
        {
            if (imageFiles.Length == 0) return;

            // Загружаем следующее изображение
            try
            {
                BitmapImage bitmap = new BitmapImage(new Uri(imageFiles[currentImageIndex]));
                displayImage.Source = bitmap;

                // Переход к следующему изображению
                currentImageIndex = (currentImageIndex + 1) % imageFiles.Length;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке изображения: {ex.Message}");
            }
        }

        // Обработчик нажатия клавиши
        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                Close(); // Закрыть окно при нажатии Enter
            }
            else if (e.Key == Key.Space)
            {
                SwitchToNextState(); // Переключить состояние при нажатии пробела
            }
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            // Путь к папке с изображениями
            try
            {
                string imagesPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "images");
                imageFiles = Directory.GetFiles(imagesPath, "*.jpg");

                if (imageFiles.Length == 0)
                {
                    MessageBox.Show("Изображения не найдены в папке 'images'. Приложение будет закрыто.");
                    Close();
                }
            }
            catch (DirectoryNotFoundException ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}. Проверьте, существует ли папка 'images' в директории проекта.");
                Close();
            }
        }

        // Метод для переключения между состояниями (для тестирования)
        public void SwitchToNextState()
        {
            SetState((state + 1) % 4);
        }
    }
}