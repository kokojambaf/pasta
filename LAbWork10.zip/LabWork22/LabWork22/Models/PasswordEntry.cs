﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabWork22.Models
{
    public class PasswordEntry
    {
        public string Site { get; set; } // Название сайта или приложения
        public string Login { get; set; } // Логин
        public string Password { get; set; } // Пароль
    }
}
