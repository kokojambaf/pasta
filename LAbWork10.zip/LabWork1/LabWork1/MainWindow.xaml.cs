﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace LabWork1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LoadProcesses();
        }

        private void LoadProcesses()
        {
            var processes = Process.GetProcesses()
        .Select(p => new ProcessInfo
        {
            Name = p.ProcessName,
            Id = p.Id,
            MemoryUsage = p.WorkingSet64 / 1024 // переведите в килобайты
        }).ToList();

            ProcessListView.ItemsSource = processes;
            StatusTextBlock.Text = $"Запущено процессов: {processes.Count}";

            // Загрузка приложений
            LoadApplications();
        }

        private void LoadApplications()
        {
            var applications = Process.GetProcesses()
                .Where(p => !string.IsNullOrEmpty(p.MainWindowTitle))
                .Select(p => new ApplicationInfo
                {
                    ApplicationTitle = p.MainWindowTitle,
                    StartTime = p.StartTime
                }).ToList();

            ApplicationListView.ItemsSource = applications;
        }

        private void KillProcessById(int processId)
        {
            try
            {
                // Получаем процесс по ID
                var process = Process.GetProcessById(processId);
                process.Kill(); // Завершение процесса
                process.WaitForExit(); // Ожидание его завершения
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при завершении процесса: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void StartTaskButton_Click(object sender, RoutedEventArgs e)
        {
            StartProcessWindow startProcessWindow = new StartProcessWindow();
            if (startProcessWindow.ShowDialog() == true) // Проверяем результат диалога
            {
                LoadProcesses(); // Обновляем список процессов после успешного запуска
            }
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadProcesses();
        }

        private void StopTaskButton_Click(object sender, RoutedEventArgs e)
        {
            if (ProcessListView.SelectedItem is ProcessInfo selectedProcess)
            {
                KillProcessById(selectedProcess.Id);
                LoadProcesses(); // Обновление списка процессов после завершения
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите процесс для завершения.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void KillAllProcessesButton_Click(object sender, RoutedEventArgs e)
        {
            Process[] processes = Process.GetProcesses();

            foreach (Process process in processes)
            {
                try
                {
                    // Проверяем, не является ли процесс системным или нашим собственным
                    if (process.Id != Process.GetCurrentProcess().Id)
                    {
                        process.Kill();
                    }
                }
                catch
                {
                    // Игнорируем процессы, которые нельзя завершить
                }
            }
            LoadProcesses(); // Обновляем список
        }
    }
}