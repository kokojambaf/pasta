﻿using System;
using System.Drawing; 
using System.IO;
using System.Windows;
using System.Windows.Media.Imaging; 

namespace LabWork12
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string captchaText; 

        public MainWindow()
        {
            InitializeComponent();
            GenerateCaptcha();
        }

        // Метод для генерации капчи
        private void GenerateCaptcha()
        {
            // Задание 1 -  Генерация случайной комбинации из шести букв и цифр
            captchaText = GenerateRandomString(6);

            // Задание 2 -  Создание объекта Bitman нужного размера
            using (Bitmap captchaImage = new Bitmap(200, 50))
            {
                using (Graphics g = Graphics.FromImage(captchaImage))
                {
                    // Заливка фона цветом
                    g.Clear(Color.AliceBlue);

                    // Добавление шума
                    AddNoise(g, 200, 50);

                    // шрифт и размер шрифта
                    Font font = new Font("Arial", 24, System.Drawing.FontStyle.Bold);

                    // Рисуем текст со случайным углом наклона
                    Random random = new Random();
                    for (int i = 0; i < captchaText.Length; i++)
                    {
                        float angle = GetRandomAngle();
                        g.TranslateTransform(30 * i, 10); // Смещение по оси X
                        g.RotateTransform(angle); // Случайный угол
                        g.DrawString(captchaText[i].ToString(), font, Brushes.Black, new PointF(0, 0));
                        g.RotateTransform(-angle); // Восстановление угла
                        g.TranslateTransform(-30 * i, -10); // Возврат позиционирования
                    }
                }

                // Сохранение изображения в поток
                using (MemoryStream ms = new MemoryStream())
                {
                    captchaImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                    ms.Position = 0;

                    // Преобразование в BitmapImage 
                    BitmapImage bi = new BitmapImage();
                    bi.BeginInit();
                    bi.StreamSource = ms;
                    bi.CacheOption = BitmapCacheOption.OnLoad;
                    bi.EndInit();
                    bi.Freeze();

                    // Отображение на форме
                    CaptchaImage.Source = bi;
                }
            }
        }

        // Генерация случайной строки
        private string GenerateRandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            Random random = new Random();
            char[] stringChars = new char[length];

            for (int i = 0; i < length; i++)
            {
                stringChars[i] = chars[random.Next(chars.Length)];
            }

            return new string(stringChars);
        }

        // Добавление шума
        private void AddNoise(Graphics g, int width, int height)
        {
            Random rand = new Random();
            for (int i = 0; i < 50; i++)
            {
                int x = rand.Next(width);
                int y = rand.Next(height);
                g.DrawLine(Pens.Gray, x, y, x + rand.Next(-5, 6), y + rand.Next(-5, 6));
            }
        }

        // Случайный угол наклона
        private float GetRandomAngle()
        {
            Random rand = new Random();
            return (float)(rand.Next(-30, 31)); // Угол от -30 до 30 градусов
        }

        // Проверка правильности ввода
        private void CheckCaptcha_Click(object sender, RoutedEventArgs e)
        {
            if (InputCaptcha.Text == captchaText)
            {
                ResultText.Text = "Капча введена правильно!";
            }
            else
            {
                ResultText.Text = "Неправильный ввод капчи.";
            }
        }
    }
}