﻿using System;
using System.Management;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Анализ автозагрузки\n");
        GetStartupPrograms(); // Получение списка программ автозагрузки
    }

    static void GetStartupPrograms()
    {
        // WQL-запрос для получения информации о командах автозагрузки
        var searcher = new ManagementObjectSearcher("SELECT * FROM Win32_StartupCommand");

        // Перебираем найденные объекты (экземпляры класса Win32_StartupCommand)
        foreach (ManagementObject startupProgram in searcher.Get())
        {
            Console.WriteLine($"Имя программы: {startupProgram["Name"]}");
            Console.WriteLine($"Команда: {startupProgram["Command"]}");
            Console.WriteLine($"Пользователь: {startupProgram["User"]}");

            Console.WriteLine("----------------------------");
        }
    }
}

