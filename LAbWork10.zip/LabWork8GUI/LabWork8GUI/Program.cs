﻿using System;
using System.Data;
using System.Diagnostics;
using Terminal.Gui;
using static System.Net.Mime.MediaTypeNames;

namespace ProcessManager
{
    class Program
    {
        private static DataTable processTable;
        private static TableView tableView;

        static void Main(string[] args)
        {
            Terminal.Gui.Application.Init();
            var top = Terminal.Gui.Application.Top;

            // Создание таблицы процессов
            processTable = new DataTable();
            processTable.Columns.Add("ID", typeof(int));
            processTable.Columns.Add("Имя процесса", typeof(string));
            processTable.Columns.Add("Использование памяти (КБ)", typeof(string));

            // Инициализация TableView
            tableView = new TableView()
            {
                Width = Dim.Fill(),
                Height = Dim.Fill(15)
            };
            tableView.Table = processTable;

            // Кнопка для обновления списка процессов
            var refreshButton = new Button("Обновить список")
            {
                X = 0,
                Y = 16
            };
            refreshButton.Clicked += UpdateProcessList;

            // Текстовое поле для ввода имени процесса
            var processNameField = new TextField("Введите имя процесса...")
            {
                X = 0,
                Y = 17,
                Width = Dim.Fill()
            };

            // Кнопка для запуска процесса
            var launchButton = new Button("Запустить")
            {
                X = 0,
                Y = 18
            };
            launchButton.Clicked += () =>
            {
                string processName = processNameField.Text.ToString();
                if (string.IsNullOrWhiteSpace(processName))
                {
                    MessageBox.ErrorQuery(50, 7, "Ошибка", "Введите имя процесса.", "OK");
                    return;
                }

                try
                {
                    Process.Start(new ProcessStartInfo(processName)
                    {
                        UseShellExecute = true
                    });
                    UpdateProcessList();
                }
                catch (Exception ex)
                {
                    MessageBox.ErrorQuery(50, 7, "Ошибка", $"Не удалось запустить процесс: {ex.Message}", "OK");
                }
            };

            // Кнопка для завершения процесса
            var killButton = new Button("Завершить")
            {
                X = 0,
                Y = 19
            };
            killButton.Clicked += () =>
            {
                if (tableView.SelectedRow >= 0)
                {
                    int selectedId = (int)processTable.Rows[tableView.SelectedRow]["ID"];
                    try
                    {
                        var process = Process.GetProcessById(selectedId);
                        process.Kill();
                        UpdateProcessList();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.ErrorQuery(50, 7, "Ошибка", $"Не удалось завершить процесс: {ex.Message}", "OK");
                    }
                }
            };

            // Создание окна
            var window = new Window("Менеджер Процессов")
            {
                Width = Dim.Fill(),
                Height = Dim.Fill()
            };
            window.Add(tableView, refreshButton, processNameField, launchButton, killButton);
            top.Add(window);

            UpdateProcessList(); // Первоначальное обновление списка процессов            

            Terminal.Gui.Application.Run();
        }

        private static void UpdateProcessList()
        {
            processTable.Rows.Clear();
            var processes = Process.GetProcesses(); // Получаем все процессы

            foreach (var process in processes)
            {
                try
                {
                    string memoryUsage = $"{process.WorkingSet64 / 1024} КБ"; // Использование памяти в КБ
                    // Добавляем информацию о процессе
                    processTable.Rows.Add(process.Id, process.ProcessName, memoryUsage);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Не удалось получить данные о процессе {process.ProcessName}: {ex.Message}");
                }
            }

            tableView.Table = processTable; // Обновление TableView с процессами
        }
    }
}

