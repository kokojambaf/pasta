%include "io.inc"
section .data
fmt db "%s", 10, 0
src db "world", 0
dst db 64 dup(0)

section .text
global main
main:
push ebp
mov ebp, esp



mov esi, src        ; ESI -> текущий символ
find_end:
cmp byte [esi], 0
je got_end
inc esi
jmp find_end
got_end:
dec esi             ; ESI -> последний символ 
mov edi, dst        ; EDI -> приёмник

copy_loop:
mov al, [esi]
mov [edi], al
dec esi
inc edi
cmp esi, src
jae copy_loop



mov al, [esi]       ; скопировать первый символ (когда ESI == src)
mov [edi], al
inc edi
mov byte [edi], 0   

push dword dst
push dword fmt
call printf
add esp, 8

mov esp, ebp
pop ebp
ret