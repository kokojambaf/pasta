﻿using System;
using System.Diagnostics;
using System.Linq;

namespace ProcessLibrary
{
        public class Tasklist
        {
            /// <summary>
            /// Выводит все запущенные процессы. 
            /// </summary>
            public void DisplayAllProcesses()
            {
                Process[] processes = Process.GetProcesses();
                foreach (var process in processes)
                {
                    Console.WriteLine($"ID: {process.Id}, Name: {process.ProcessName}");
                }
            }

            /// <summary>
            /// Находит процесс с наибольшим идентификатором.
            /// </summary>
            /// <returns>Процесс с наибольшим ID или null, если процессов нет.</returns> 
            public Process GetProcessWithMaxId()
            {
                Process[] processes = Process.GetProcesses();
                return processes.OrderByDescending(p => p.Id).FirstOrDefault();
            }

            /// <summary>
            /// Выводит информацию о процессе по его имени. 
            /// </summary>
            /// <param name="processName">Имя процесса.</param>
            public void DisplayProcessInfoByName(string processName)
            {
                Process[] processes = Process.GetProcessesByName(processName);
                if (processes.Length == 0)
                {
                    Console.WriteLine($"Процесс с именем {processName} не найден.");
                    return;
                }

                foreach (var process in processes)
                {
                    Console.WriteLine($"ID: {process.Id}, Name: {process.ProcessName}, Start Time: {process.StartTime}");
                }
            }

            /// <summary>
            /// Запускает новый процесс по заданному пути. 
            /// </summary>
            /// <param name="processPath">Путь к исполняемому файлу процесса.</param>
            public void StartNewProcess(string processPath)
            {
                try
                {
                    Process.Start(processPath);
                    Console.WriteLine($"Процесс {processPath} запущен.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка при запуске процесса: {ex.Message}");
                }
            }
        }
    }