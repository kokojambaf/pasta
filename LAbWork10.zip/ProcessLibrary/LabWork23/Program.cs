﻿using ProcessLibrary;

class Program
{
    static void Main(string[] args)
    {
        Tasklist tasklist = new Tasklist();

        tasklist.DisplayAllProcesses();
        var maxProcess = tasklist.GetProcessWithMaxId();
        if (maxProcess != null)
        {
            Console.WriteLine($"Процесс с наибольшим ID: {maxProcess.Id} — {maxProcess.ProcessName}");
        }

        Console.WriteLine("Введите имя процесса для вывода информации:");
        string processName = Console.ReadLine();
        tasklist.DisplayProcessInfoByName(processName);

        Console.WriteLine("Введите путь к исполняемому файлу для запуска нового процесса:");
        string processPath = Console.ReadLine();
        tasklist.StartNewProcess(processPath);
    }
}
