﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabWork1
{
    public class ApplicationInfo
    {
        public string ApplicationTitle { get; set; }
        public DateTime StartTime { get; set; }
    }
}
