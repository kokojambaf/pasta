﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace Server
{
    class Program
    {
        static void Main(string[] args)
        {
            TcpListener listener = new TcpListener(IPAddress.Any, 5000);
            listener.Start();
            Console.WriteLine("Сервер запущен. Ожидание подключения клиентов...");

            while (true)
            {
                TcpClient client = listener.AcceptTcpClient();
                Console.WriteLine("Клиент подключен.");

                Thread clientThread = new Thread(() => HandleClient(client));
                clientThread.Start();
            }
        }

        private static void HandleClient(TcpClient client)
        {
            NetworkStream stream = client.GetStream();

            // Запрашиваем аутентификацию
            if (!Authenticate(stream, out string userLogin))
            {
                client.Close();
                return; // Закрыть соединение, если аутентификация не удалась
            }

            // Сообщение об успешной аутентификации
            string welcomeMessage = "Вы успешно аутентифицированы. Теперь вы можете отправлять сообщения.";
            byte[] welcomeBytes = Encoding.UTF8.GetBytes(welcomeMessage);
            stream.Write(welcomeBytes, 0, welcomeBytes.Length);

            // Получение и отображение сообщений от клиента в цикле
            while (true)
            {
                byte[] buffer = new byte[256];
                int bytesRead = stream.Read(buffer, 0, buffer.Length);

                if (bytesRead == 0) // Если клиент отключен
                {
                    Console.WriteLine($"Клиент {userLogin} отключен.");
                    break;
                }

                string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                // Выводим сообщение с указанием логина пользователя
                Console.WriteLine($"[{userLogin}] Дата получения: {DateTime.Now}");
                Console.WriteLine($"Полученное сообщение: {message}");

                // Отправляю подтверждение обратно клиенту о получении сообщения
                string responseMessage = "Сообщение получено.";
                byte[] responseMessageBytes = Encoding.UTF8.GetBytes(responseMessage);
                stream.Write(responseMessageBytes, 0, responseMessageBytes.Length);
            }

            client.Close(); // Закрываем соединение с клиентом
        }

        private static bool Authenticate(NetworkStream stream, out string userLogin)
        {
            userLogin = ""; // Инициализируем логин

            string loginPrompt = "Введите логин: ";
            byte[] loginPromptData = Encoding.UTF8.GetBytes(loginPrompt);
            stream.Write(loginPromptData, 0, loginPromptData.Length);

            byte[] buffer = new byte[256];
            int bytesRead = stream.Read(buffer, 0, buffer.Length);
            userLogin = Encoding.UTF8.GetString(buffer, 0, bytesRead).Trim(); // Получаем логин

            string passwordPrompt = "Введите пароль: ";
            byte[] passwordPromptData = Encoding.UTF8.GetBytes(passwordPrompt);
            stream.Write(passwordPromptData, 0, passwordPromptData.Length);

            bytesRead = stream.Read(buffer, 0, buffer.Length);
            string password = Encoding.UTF8.GetString(buffer, 0, bytesRead).Trim(); // Получаем пароль

            // Проверка данных из файла UserData.txt
            string[] userData = File.ReadAllLines("UserData.txt");
            foreach (string user in userData)
            {
                var parts = user.Split(':');
                if (parts[0] == userLogin && parts[1] == password)
                {
                    return true; // Успешная аутентификация
                }
            }

            // Если аутентификация не удалась, отправляем сообщение об ошибке
            string invalidDataMessage = "Неверный логин или пароль.";
            byte[] invalidDataBytes = Encoding.UTF8.GetBytes(invalidDataMessage);
            stream.Write(invalidDataBytes, 0, invalidDataBytes.Length);
            return false; // Аутентификация не удалась
        }
    }
}
