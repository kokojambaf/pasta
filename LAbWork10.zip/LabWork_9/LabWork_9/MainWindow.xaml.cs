﻿using System.Collections.ObjectModel;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System;

namespace LabWork_9
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            CurrentFolderTextBox.Text = @"C:\"; // Устанавливаем значение по умолчанию
            LoadDrives();  // Загружаем диски при запуске
        }

        // Метод для получения иконки по расширению файла
        private BitmapImage GetFileIcon(string fileName)
        {
            string extension = System.IO.Path.GetExtension(fileName).ToLower();

            return extension switch
            {
                ".txt" => new BitmapImage(new Uri("pack://application:,,,/Assest/1.png")),
                ".jpg" => new BitmapImage(new Uri("pack://application:,,,/Assest/2.png")),
                ".png" => new BitmapImage(new Uri("pack://application:,,,/Assest/3.png")),
                _ => new BitmapImage(new Uri("pack://application:,,,/Assest/4.png")), // Иконка по умолчанию
            };
        }

        // Метод для загрузки доступных дисков
        private void LoadDrives()
        {
            foreach (var drive in DriveInfo.GetDrives())
            {
                if (drive.IsReady)
                {
                    TreeViewItem item = new TreeViewItem
                    {
                        Header = drive.Name,
                        Tag = drive.RootDirectory.FullName
                    };

                    // Добавляем иконку диска
                    StackPanel panel = new StackPanel { Orientation = Orientation.Horizontal };
                    panel.Children.Add(new Image { Source = new BitmapImage(new Uri("pack://application:,,,/Assest/5.png")), Width = 16, Height = 16 });
                    panel.Children.Add(new TextBlock { Text = drive.Name, Margin = new Thickness(5, 0, 0, 0) });

                    item.Header = panel; // Устанавливаем StackPanel как заголовок элемента
                    item.Items.Add(null);
                    item.Expanded += Folder_Expanded;
                    FoldersTreeView.Items.Add(item);
                }
            }
        }

        // Обработчик изменения выбранного элемента в дереве папок
        private void FoldersTreeView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            if (e.NewValue is TreeViewItem item && item.Tag is string path)
            {
                CurrentFolderTextBox.Text = path;
                LoadFiles(path);
            }
        }

        // Загружаем файлы из указанной папки
        private void LoadFiles(string path)
        {
            FilesListBox.Items.Clear();
            try
            {
                foreach (var file in Directory.GetFiles(path))
                {
                    var fileInfo = new FileInfo(file);
                    // Create a new FileInfoModel for the current file
                    var model = new FileInfoModel
                    {
                        Name = fileInfo.Name,
                        Type = fileInfo.Extension,
                        ModifiedDate = fileInfo.LastWriteTime.ToString("g"), // Format datetime
                        Icon = GetFileIcon(file)
                    };

                    // Add the model to the ListBox
                    FilesListBox.Items.Add(model);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Обработчик для загрузки подкаталогов
        private void Folder_Expanded(object sender, RoutedEventArgs e)
        {
            TreeViewItem item = sender as TreeViewItem;
            if (item != null && item.Items.Count == 1 && item.Items[0] == null)
            {
                item.Items.Clear();
                string path = item.Tag.ToString();
                try
                {
                    foreach (var dir in Directory.GetDirectories(path))
                    {
                        TreeViewItem subItem = new TreeViewItem
                        {
                            Header = new StackPanel
                            {
                                Orientation = Orientation.Horizontal,
                                Children =
                                {
                                    new Image { Source = new BitmapImage(new Uri("pack://application:,,,/Assest/6.png")), Width = 16, Height = 16 },
                                    new TextBlock { Text = System.IO.Path.GetFileName(dir), Margin = new Thickness(5, 0, 0, 0) }
                                }
                            },
                            Tag = dir
                        };
                        subItem.Items.Add(null);
                        subItem.Expanded += Folder_Expanded;
                        item.Items.Add(subItem);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        // Обработчик для изменения текста в поле ввода
        private void CurrentFolderTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Directory.Exists(CurrentFolderTextBox.Text))
            {
                LoadFiles(CurrentFolderTextBox.Text);
            }
        }

        // Обработчик закрытия приложения
        private void ExitMenuItem_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void ArchiveFolder(string sourceFolderPath)
        {
            try
            {
                // Устанавливаем путь для архива в пользовательскую папку
                string zipFilePath = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), $"{System.IO.Path.GetFileName(sourceFolderPath)}.zip");

                // Архивируем папку
                ZipFile.CreateFromDirectory(sourceFolderPath, zipFilePath);
                MessageBox.Show($"Папка успешно заархивирована: {zipFilePath}", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка архивирования: {ex.Message}\nПуть: {sourceFolderPath}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ArchiveButton_Click(object sender, RoutedEventArgs e)
        {
            if (FoldersTreeView.SelectedItem is TreeViewItem selectedItem && selectedItem.Tag is string folderPath)
            {
                if (Directory.Exists(folderPath)) // Проверка существования папки
                {
                    ArchiveFolder(folderPath);
                }
                else
                {
                    MessageBox.Show("Выбранный путь не существует.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите папку для архивирования.", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

    }

    public class FileInfoModel
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public string ModifiedDate { get; set; }
        public BitmapImage Icon { get; set; }
    }
 }