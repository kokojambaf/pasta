%include "io.inc"
section .data
fmt_s   db "%s",0
fmt_d   db "%d",0

buf db 256 dup(0)    ; буфер для ввода
len_val dd 0             ; место для длины
section .text
global main
main:
push ebp
mov ebp, esp

; ввод строки 
push dword buf
push dword fmt_s
call scanf
add esp,8

; подсчёт длины
xor ecx, ecx
lea esi, [buf]
.len_loop:
mov al, [esi + ecx]
cmp al, 0
je .store_len
inc ecx
jmp .len_loop

.store_len:
mov [len_val], ecx



; вывести длину
push dword [len_val]
push dword fmt_d
call printf
add esp,8

mov esp, ebp
pop ebp
ret