﻿using System;
using System.IO;
using System.Management;
using System.Threading;

class Program
{
    static void Main(string[] args)
    {
        string logFilePath = @"C:\resolution_log.txt";
        string lastResolution = GetCurrentResolution();

        while (true)
        {
            Thread.Sleep(5000); // Задержка 5 секунд
            string currentResolution = GetCurrentResolution();

            // Проверка изменения разрешения экрана
            if (currentResolution != lastResolution)
            {
                Console.WriteLine($"Разрешение изменено: {currentResolution}");
                LogResolutionChange(logFilePath, currentResolution);
                lastResolution = currentResolution; // Обновляем последнее разрешение
            }
        }
    }

    // Метод для получения текущего разрешения экрана
    static string GetCurrentResolution()
    {
        string resolution = string.Empty;
        ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT ScreenWidth, ScreenHeight FROM Win32_DesktopMonitor");
        foreach (ManagementObject monitor in searcher.Get())
        {
            // Получаем разрешение
            int width = Convert.ToInt32(monitor["ScreenWidth"]);
            int height = Convert.ToInt32(monitor["ScreenHeight"]);
            resolution = $"{width}x{height}"; // Форматируем разрешение
        }
        return resolution;
    }

    // Метод для записи в лог-файл
    static void LogResolutionChange(string filePath, string resolution)
    {
        try
        {
            // Создание директории, если она не существует
            var directory = Path.GetDirectoryName(filePath);
            if (!Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }

            // Запись в файл
            using (StreamWriter writer = new StreamWriter(filePath, true))
            {
                writer.WriteLine($"{DateTime.Now}: Разрешение изменено на {resolution}");
            }
        }
        catch (Exception ex)
        {
            // Вывод сообщения об ошибке
            Console.WriteLine("Ошибка при записи в файл: " + ex.Message);
        }
    }
}
