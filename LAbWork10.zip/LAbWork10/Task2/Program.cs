﻿using System;
using System.Management;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Мониторинг накопителей\n");
        GetDiskSpace(); // Получение информации о логических дисках
    }

    static void GetDiskSpace()
    {
        // WQL-запрос для получения информации о логических дисках типа 3 (жесткий диск)
        var searcher = new ManagementObjectSearcher("SELECT Name, FileSystem, Size, FreeSpace FROM Win32_LogicalDisk WHERE DriveType = 3");

        // Перебираем найденные объекты (экземпляры класса Win32_LogicalDisk)
        foreach (ManagementObject disk in searcher.Get())
        {
            Console.WriteLine($"Диск: {disk["Name"]}");
            Console.WriteLine($"Файловая система: {disk["FileSystem"]}");
            long totalSize = Convert.ToInt64(disk["Size"]) / (1024 * 1024 * 1024); // Преобразование в ГБ
            Console.WriteLine($"Всего: {totalSize} ГБ");
            long freeSpace = Convert.ToInt64(disk["FreeSpace"]) / (1024 * 1024 * 1024); // Преобразование в ГБ
            Console.WriteLine($"Свободно: {freeSpace} ГБ");

            // Вычисление процента свободного места
            double freePercentage = (double)freeSpace / totalSize * 100;
            Console.WriteLine($"Процент свободного места: {freePercentage:F2}%");
            Console.WriteLine("----------------------------"); 
        }
    }
}

