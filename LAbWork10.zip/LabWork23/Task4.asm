%include "io.inc"
section .data
str1 db "Hello", 0
char db 'o'

section .text
global main
main:
mov ebp, esp ; for correct debugging
xor eax, eax



mov edi, str1       ; EDI -> строка
mov al, [char]      ; AL = искомый символ
cld                 ; DF=0 (движение вперёд)

; посчитать длину строки 
mov ecx, -1
xor al, al
mov edi, str1
repne scasb
not ecx
dec ecx             ; ECX = длина строки

; поиск: установим EDI и ECX заново
mov edi, str1
mov al, [char]
mov ebx, ecx        ; EBX = длина
mov ecx, ebx
repne scasb

jne .notfound

mov eax, ebx
sub eax, ecx
dec eax
PRINT_STRING "Found"
NEWLINE
PRINT_DEC 4, eax
jmp .end
.notfound:
PRINT_STRING "Not Found"

.end:
ret