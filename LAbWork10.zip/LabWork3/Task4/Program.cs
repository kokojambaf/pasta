﻿using System;
using System.Threading;

class Program
{
    // Глобальная переменная для обмена данными между потоками
    private static string commonVar = string.Empty;
    private static readonly object lockObject = new object();
    private static volatile bool isRunning = true; // Переменная для управления завершением

    static void Main(string[] args)
    {
        // Создание и запуск второго потока
        Thread myThread = new Thread(MyThread);
        myThread.Start();

        // Основной поток будет обновлять значение commonVar с буквами от 'a' до 'z'
        for (char c = 'a'; c <= 'z'; c++)
        {
            lock (lockObject)
            {
                commonVar = c.ToString();
                Console.WriteLine($"Поток Main: {commonVar}");
            }
            Thread.Sleep(200); // Задержка
        }

        // Присвоение значения 'x' для завершения второго потока
        lock (lockObject)
        {
            commonVar = "x";
            isRunning = false; // Меняем состояние на завершение
        }

        // Ждем завершения потока MyThread
        myThread.Join();
    }

    static void MyThread()
    {
        string lastValue = string.Empty;

        while (isRunning) // Проверяем состояние для продолжения работы
        {
            string value;
            lock (lockObject)
            {
                value = commonVar;
            }

            // Проверяем значение для завершения
            if (value == "x")
            {
                Console.WriteLine("Поток MyThread: Получено значение 'x'. Завершение потока.");
                break;
            }

            // Если значение не пустое и изменилось, выводим
            if (!string.IsNullOrEmpty(value) && value != lastValue)
            {
                Console.WriteLine($"Поток MyThread: {value}");
                lastValue = value; // Обновляем предыдущее значение
            }

            Thread.Sleep(100);
        }
    }
}