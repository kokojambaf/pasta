﻿using System;
using System.Threading;

class Program
{
    static void Main(string[] args)
    {
        // Создание потоков
        Thread numberThread = new Thread(PrintNumbers);
        Thread letterThread = new Thread(PrintLetters);

        // Запуск потоков
        numberThread.Start();
        letterThread.Start();

        // Ждем завершения потоков
        numberThread.Join();
        letterThread.Join();
    }

    static void PrintNumbers()
    {
        for (int i = 0; i <= 9; i++)
        {
            Console.WriteLine(i);
            Thread.Sleep(200); // Задержка
        }
    }

    static void PrintLetters()
    {
        for (char c = 'A'; c <= 'J'; c++)
        {
            Console.WriteLine(c);
            Thread.Sleep(200); // Задержка
        }
    }
}

