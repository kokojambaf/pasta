%include "io.inc"
section .data
fmt_s   db "%s",0        ; формат ввода строки
; сообщения
ok_msg  db "Access granted",0
no_msg  db "Wrong password",0



passwd  db "password",0    ; эталонный пароль
buf     db 256 dup(0)    ; буфер для ввода
section .text
global main
main:
push ebp
mov ebp, esp



; ввод пароля в buf (scanf "%s")
push dword buf
push dword fmt_s
call scanf
add esp,8

; сравнение строк passwd и buf
mov esi, passwd      ; ESI -> эталон
mov edi, buf         ; EDI -> введённый
.compare:
mov al, [esi]        ; байт эталона
mov bl, [edi]        ; байт ввода
cmp al, bl
jne .not_equal
cmp al, 0            ; если достигли конца и равны — строки одинаковы
je .equal
inc esi
inc edi
jmp .compare

.equal:
PRINT_STRING ok_msg
jmp .end

.not_equal:
PRINT_STRING no_msg

.end:
mov esp, ebp
pop ebp
ret