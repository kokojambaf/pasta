﻿using System;
using System.Threading;

class Program
{
    // Общая переменная
    private static int sharedCounter = 0;
    // Объект блокировки
    private static readonly object lockObject = new object();

    static void Main(string[] args)
    {
        // Создание потоков
        Thread thread1 = new Thread(IncrementCounter);
        Thread thread2 = new Thread(IncrementCounter);

        // Запуск потоков
        thread1.Start();
        thread2.Start();

        // Ждем завершения потоков
        thread1.Join();
        thread2.Join();

        // Вывод результата
        Console.WriteLine($"Финальное значение счетчика: {sharedCounter}");
    }

    static void IncrementCounter()
    {
        for (int i = 0; i < 1000; i++)
        {
            // Блокировка доступа к общей переменной
            lock (lockObject)
            {
                sharedCounter++;
            }
        }
    }
}

